'use strict';
/**
 * Server Chat Kelas IX.6  -  tanpa dependency (cuma Node.js bawaan)
 * Jalankan:  node server.js   ->  buka http://localhost:3000
 * Database : data/db.json  (JSON, otomatis dibuat)
 * Upload   : data/uploads/ (foto profil, foto grup, foto chat, foto status)
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const PUBLIC_DIR = path.join(__dirname, 'public');
const DB_FILE = path.join(DATA_DIR, 'db.json');

/* Hanya 4 orang ini yang boleh punya akun. 1 nama = 1 akun. */
const ALLOWED = ['Rizky', 'Chalista', 'Syakina', 'Nadira'];
const STATUS_TTL = 24 * 60 * 60 * 1000;
const MAX_UPLOAD = 6 * 1024 * 1024;

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

/* ================= DATABASE (JSON) ================= */
let db = { users: {}, sessions: {}, chats: {}, messages: {}, channels: {}, posts: {}, statuses: [] };
try {
  const raw = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  db = Object.assign(db, raw);
} catch (e) { /* db baru */ }

let saveTimer = null;
function saveDb() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    const tmp = DB_FILE + '.tmp';
    fs.writeFile(tmp, JSON.stringify(db), err => {
      if (!err) fs.rename(tmp, DB_FILE, () => {});
    });
  }, 250);
}
function flushSync() {
  try { fs.writeFileSync(DB_FILE, JSON.stringify(db)); } catch (e) {}
}
process.on('SIGINT', () => { flushSync(); process.exit(0); });
process.on('SIGTERM', () => { flushSync(); process.exit(0); });

/* ================= UTIL ================= */
const rid = (n = 8) => crypto.randomBytes(n).toString('hex');
const now = () => Date.now();
const clip = (s, n) => String(s == null ? '' : s).slice(0, n);

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
const fail = (res, code, msg) => send(res, code, { error: msg });

function readBody(req, limit = 200 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => {
      size += c.length;
      if (size > limit) { reject(new Error('too_big')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch (e) { reject(new Error('bad_json')); }
    });
    req.on('error', reject);
  });
}

function hashPw(pw, salt) { return crypto.scryptSync(String(pw), salt, 32).toString('hex'); }
function checkPw(pw, user) {
  const a = Buffer.from(hashPw(pw, user.salt), 'hex');
  const b = Buffer.from(user.hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const URL_RE = /^\/uploads\/[a-f0-9]{16,}\.(jpg|png|webp|gif)$/;
const cleanUrl = u => (typeof u === 'string' && URL_RE.test(u) && fs.existsSync(path.join(DATA_DIR, u))) ? u : null;
const cleanColor = c => (typeof c === 'string' && /^#[0-9a-fA-F]{6}$/.test(c)) ? c : '#9d4edd';

/* ================= REALTIME (SSE) ================= */
const clients = new Map(); // userId -> Set(res)
function isOnline(uid) { return clients.has(uid) && clients.get(uid).size > 0; }
function push(userIds, event, data) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const uid of new Set(userIds)) {
    const set = clients.get(uid);
    if (set) for (const r of set) { try { r.write(payload); } catch (e) {} }
  }
}
const allUserIds = () => Object.keys(db.users);

/* ================= MODEL HELPERS ================= */
function pubUser(u) {
  return { id: u.id, name: u.name, avatar: u.avatar || null, about: u.about || '', online: isOnline(u.id), lastSeen: u.lastSeen || 0 };
}
function dmId(a, b) { return 'dm_' + [a, b].sort().join('_'); }

function authUser(req, urlObj) {
  let token = null;
  const h = req.headers['authorization'];
  if (h && h.startsWith('Bearer ')) token = h.slice(7);
  else if (urlObj && urlObj.searchParams.get('token')) token = urlObj.searchParams.get('token');
  if (!token) return null;
  const uid = db.sessions[token];
  return uid && db.users[uid] ? db.users[uid] : null;
}

function chatMsgs(id) { return db.messages[id] || (db.messages[id] = []); }
function isMember(chat, uid) { return chat.members.includes(uid); }

function lastMsgPreview(m) {
  if (!m) return null;
  return { id: m.id, from: m.from, type: m.type, text: m.deleted ? '' : clip(m.text, 80), image: !!m.image && !m.deleted, deleted: !!m.deleted, ts: m.ts };
}
function chatSummary(chat, uid) {
  const msgs = chatMsgs(chat.id);
  let unread = 0;
  for (const m of msgs) if (m.from !== uid && m.type !== 'system' && !m.deleted && !(m.readBy || []).includes(uid)) unread++;
  return {
    id: chat.id, type: chat.type, name: chat.name || '', photo: chat.photo || null, description: chat.description || '',
    members: chat.members, admins: chat.admins || [], createdBy: chat.createdBy || null, createdAt: chat.createdAt,
    last: lastMsgPreview(msgs[msgs.length - 1]), unread, updatedAt: chat.updatedAt || chat.createdAt
  };
}
function channelSummary(ch, uid) {
  const posts = db.posts[ch.id] || [];
  const last = posts[posts.length - 1];
  return {
    id: ch.id, name: ch.name, description: ch.description || '', photo: ch.photo || null, owner: ch.owner,
    followers: ch.followers.length, following: ch.followers.includes(uid), createdAt: ch.createdAt,
    last: last ? { text: clip(last.text, 80), image: !!last.image, ts: last.ts } : null
  };
}
function visibleStatuses() {
  const t = now();
  return db.statuses.filter(s => s.expires > t);
}
function statusView(s, uid) {
  const groups = (s.tags.groups || []).map(gid => db.chats[gid]).filter(Boolean).map(g => ({ id: g.id, name: g.name }));
  const out = {
    id: s.id, userId: s.userId, type: s.type, text: s.text || '', bg: s.bg, image: s.image || null, caption: s.caption || '',
    ts: s.ts, expires: s.expires, tags: { users: s.tags.users || [], groups },
    viewed: s.userId === uid ? true : s.viewers.some(v => v.id === uid),
    viewCount: s.viewers.length
  };
  if (s.userId === uid) out.viewers = s.viewers;
  return out;
}
function bootstrap(u) {
  const chats = Object.values(db.chats).filter(c => isMember(c, u.id)).map(c => chatSummary(c, u.id));
  return {
    me: pubUser(u),
    users: Object.values(db.users).map(pubUser),
    chats,
    channels: Object.values(db.channels).map(c => channelSummary(c, u.id)),
    statuses: visibleStatuses().map(s => statusView(s, u.id)),
    now: now()
  };
}

function addMessage(chat, from, data) {
  const m = Object.assign({ id: 'm_' + rid(6), chatId: chat.id, from, type: 'text', text: '', image: null, replyTo: null, statusRef: null, ts: now(), deleted: false, readBy: [from] }, data);
  chatMsgs(chat.id).push(m);
  chat.updatedAt = m.ts;
  push(chat.members, 'message', { msg: m });
  saveDb();
  return m;
}
function ensureDm(a, b) {
  const id = dmId(a, b);
  if (!db.chats[id]) db.chats[id] = { id, type: 'dm', members: [a, b], createdAt: now(), updatedAt: now() };
  return db.chats[id];
}

/* ================= HANDLERS ================= */
const failCount = new Map(); // ip -> {n, until}
function tooMany(ip) { const f = failCount.get(ip); return f && f.n >= 8 && f.until > now(); }
function noteFail(ip) { const f = failCount.get(ip) || { n: 0, until: 0 }; f.n++; f.until = now() + 5 * 60 * 1000; failCount.set(ip, f); }

async function api(req, res, urlObj) {
  const p = urlObj.pathname;
  const method = req.method;
  const ip = req.socket.remoteAddress;

  /* ---------- publik ---------- */
  if (method === 'GET' && p === '/api/slots') {
    const taken = new Set(Object.values(db.users).map(u => u.name.toLowerCase()));
    return send(res, 200, { slots: ALLOWED.map(n => ({ name: n, taken: taken.has(n.toLowerCase()) })) });
  }

  if (method === 'POST' && p === '/api/register') {
    const b = await readBody(req);
    const name = ALLOWED.find(n => n.toLowerCase() === String(b.name || '').trim().toLowerCase());
    if (!name) return fail(res, 400, 'Hanya Rizky, Chalista, Syakina, dan Nadira yang boleh daftar.');
    const id = name.toLowerCase();
    if (db.users[id]) return fail(res, 409, 'Akun ' + name + ' sudah dibuat. 1 orang cuma boleh 1 akun.');
    const pw = String(b.password || '');
    if (pw.length < 4) return fail(res, 400, 'Password minimal 4 karakter.');
    const salt = rid(8);
    db.users[id] = { id, name, salt, hash: hashPw(pw, salt), avatar: null, about: 'Hey there! I am using Chat IX.6', createdAt: now(), lastSeen: now() };
    const token = rid(24);
    db.sessions[token] = id;
    saveDb();
    push(allUserIds(), 'sync', { what: 'users' });
    return send(res, 200, { token, me: pubUser(db.users[id]) });
  }

  if (method === 'POST' && p === '/api/login') {
    if (tooMany(ip)) return fail(res, 429, 'Terlalu banyak percobaan. Coba lagi 5 menit lagi.');
    const b = await readBody(req);
    const id = String(b.name || '').trim().toLowerCase();
    const u = db.users[id];
    if (!u || !checkPw(b.password || '', u)) { noteFail(ip); return fail(res, 401, 'Nama atau password salah.'); }
    failCount.delete(ip);
    const token = rid(24);
    db.sessions[token] = u.id;
    saveDb();
    return send(res, 200, { token, me: pubUser(u) });
  }

  /* ---------- SSE ---------- */
  if (method === 'GET' && p === '/api/events') {
    const u = authUser(req, urlObj);
    if (!u) return fail(res, 401, 'unauthorized');
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    res.write('retry: 2500\n\nevent: hello\ndata: {}\n\n');
    if (!clients.has(u.id)) clients.set(u.id, new Set());
    const wasOnline = isOnline(u.id);
    clients.get(u.id).add(res);
    if (!wasOnline) push(allUserIds(), 'presence', { userId: u.id, online: true, lastSeen: now() });
    const ka = setInterval(() => { try { res.write(': ka\n\n'); } catch (e) {} }, 25000);
    req.on('close', () => {
      clearInterval(ka);
      const set = clients.get(u.id);
      if (set) { set.delete(res); if (!set.size) clients.delete(u.id); }
      if (!isOnline(u.id)) {
        u.lastSeen = now(); saveDb();
        push(allUserIds(), 'presence', { userId: u.id, online: false, lastSeen: u.lastSeen });
      }
    });
    return;
  }

  /* ---------- wajib login ---------- */
  const me = authUser(req, urlObj);
  if (!me) return fail(res, 401, 'Silakan masuk dulu.');

  if (method === 'POST' && p === '/api/logout') {
    const h = req.headers['authorization'] || '';
    delete db.sessions[h.slice(7)];
    saveDb();
    return send(res, 200, { ok: true });
  }

  if (method === 'GET' && p === '/api/bootstrap') return send(res, 200, bootstrap(me));

  if (method === 'POST' && p === '/api/upload') {
    const b = await readBody(req, 9 * 1024 * 1024);
    const m = /^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/.exec(String(b.dataUrl || ''));
    if (!m) return fail(res, 400, 'Format gambar tidak didukung.');
    const buf = Buffer.from(m[2], 'base64');
    if (buf.length > MAX_UPLOAD) return fail(res, 413, 'Gambar terlalu besar (maks 6MB).');
    const isJpg = buf[0] === 0xff && buf[1] === 0xd8;
    const isPng = buf[0] === 0x89 && buf.slice(1, 4).toString() === 'PNG';
    const isGif = buf.slice(0, 3).toString() === 'GIF';
    const isWebp = buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP';
    const ext = isJpg ? 'jpg' : isPng ? 'png' : isGif ? 'gif' : isWebp ? 'webp' : null;
    if (!ext) return fail(res, 400, 'File bukan gambar yang valid.');
    const name = rid(12) + '.' + ext;
    fs.writeFileSync(path.join(UPLOAD_DIR, name), buf);
    return send(res, 200, { url: '/uploads/' + name });
  }

  if (method === 'POST' && p === '/api/profile') {
    const b = await readBody(req);
    if ('about' in b) me.about = clip(b.about, 140);
    if ('avatar' in b) me.avatar = b.avatar === null ? null : (cleanUrl(b.avatar) || me.avatar);
    saveDb();
    push(allUserIds(), 'sync', { what: 'users' });
    return send(res, 200, { me: pubUser(me) });
  }

  if (method === 'POST' && p === '/api/typing') {
    const b = await readBody(req);
    const chat = db.chats[b.chatId];
    if (chat && isMember(chat, me.id)) push(chat.members.filter(x => x !== me.id), 'typing', { chatId: chat.id, userId: me.id });
    return send(res, 200, { ok: true });
  }

  /* ---------- CHAT ---------- */
  if (method === 'POST' && p === '/api/chats/dm') {
    const b = await readBody(req);
    const other = db.users[b.userId];
    if (!other || other.id === me.id) return fail(res, 400, 'Pengguna tidak valid.');
    const chat = ensureDm(me.id, other.id);
    saveDb();
    return send(res, 200, { chat: chatSummary(chat, me.id) });
  }

  if (method === 'POST' && p === '/api/chats/group') {
    const b = await readBody(req);
    const name = clip(b.name, 40).trim();
    if (!name) return fail(res, 400, 'Nama grup wajib diisi.');
    const members = [...new Set([me.id, ...(Array.isArray(b.members) ? b.members : [])])].filter(id => db.users[id]);
    if (members.length < 2) return fail(res, 400, 'Pilih minimal 1 anggota lain.');
    const id = 'g_' + rid(6);
    const chat = db.chats[id] = { id, type: 'group', name, description: clip(b.description, 200), photo: cleanUrl(b.photo), members, admins: [me.id], createdBy: me.id, createdAt: now(), updatedAt: now() };
    addMessage(chat, me.id, { type: 'system', text: me.name + ' membuat grup "' + name + '"' });
    push(chat.members, 'chat', { chatId: id });
    return send(res, 200, { chat: chatSummary(chat, me.id) });
  }

  let m;
  if ((m = /^\/api\/chats\/([\w]+)\/(messages|read|update|leave)$/.exec(p))) {
    const chat = db.chats[m[1]];
    if (!chat || !isMember(chat, me.id)) return fail(res, 404, 'Obrolan tidak ditemukan.');
    const action = m[2];

    if (method === 'GET' && action === 'messages') return send(res, 200, { messages: chatMsgs(chat.id).slice(-500) });

    if (method === 'POST' && action === 'messages') {
      const b = await readBody(req);
      const text = clip(b.text, 4000).trim();
      const image = cleanUrl(b.image);
      if (!text && !image) return fail(res, 400, 'Pesan kosong.');
      let replyTo = null;
      if (b.replyTo) {
        const o = chatMsgs(chat.id).find(x => x.id === b.replyTo);
        if (o && !o.deleted) replyTo = { id: o.id, from: o.from, text: clip(o.text, 100), image: !!o.image, type: o.type };
      }
      let statusRef = null;
      if (b.statusRef) {
        const s = db.statuses.find(x => x.id === b.statusRef);
        if (s) statusRef = { id: s.id, ownerId: s.userId, type: s.type, text: clip(s.text || s.caption, 80), image: s.image || null, bg: s.bg };
      }
      const msg = addMessage(chat, me.id, { text, image, replyTo, statusRef });
      return send(res, 200, { msg });
    }

    if (method === 'POST' && action === 'read') {
      let changed = false;
      for (const x of chatMsgs(chat.id)) if (x.from !== me.id && !x.readBy.includes(me.id)) { x.readBy.push(me.id); changed = true; }
      if (changed) { saveDb(); push(chat.members, 'read', { chatId: chat.id, userId: me.id }); }
      return send(res, 200, { ok: true });
    }

    if (method === 'POST' && action === 'update') {
      if (chat.type !== 'group') return fail(res, 400, 'Hanya untuk grup.');
      if (!chat.admins.includes(me.id)) return fail(res, 403, 'Hanya admin grup yang bisa mengubah.');
      const b = await readBody(req);
      if (typeof b.name === 'string' && b.name.trim() && b.name.trim() !== chat.name) {
        const old = chat.name; chat.name = clip(b.name, 40).trim();
        addMessage(chat, me.id, { type: 'system', text: me.name + ' mengubah nama grup dari "' + old + '" menjadi "' + chat.name + '"' });
      }
      if (typeof b.description === 'string') chat.description = clip(b.description, 200);
      if ('photo' in b) {
        const np = b.photo === null ? null : cleanUrl(b.photo);
        if (b.photo === null || np) { chat.photo = np; addMessage(chat, me.id, { type: 'system', text: me.name + ' mengubah foto grup' }); }
      }
      if (Array.isArray(b.addMembers)) {
        for (const id of b.addMembers) if (db.users[id] && !chat.members.includes(id)) {
          chat.members.push(id);
          addMessage(chat, me.id, { type: 'system', text: me.name + ' menambahkan ' + db.users[id].name });
        }
      }
      if (Array.isArray(b.removeMembers)) {
        for (const id of b.removeMembers) if (id !== me.id && chat.members.includes(id)) {
          chat.members = chat.members.filter(x => x !== id);
          chat.admins = chat.admins.filter(x => x !== id);
          addMessage(chat, me.id, { type: 'system', text: me.name + ' mengeluarkan ' + db.users[id].name });
          push([id], 'chat', { chatId: chat.id, removed: true });
        }
      }
      if (Array.isArray(b.makeAdmin)) for (const id of b.makeAdmin) if (chat.members.includes(id) && !chat.admins.includes(id)) chat.admins.push(id);
      chat.updatedAt = now();
      saveDb();
      push(chat.members, 'chat', { chatId: chat.id });
      return send(res, 200, { chat: chatSummary(chat, me.id) });
    }

    if (method === 'POST' && action === 'leave') {
      if (chat.type !== 'group') return fail(res, 400, 'Hanya untuk grup.');
      addMessage(chat, me.id, { type: 'system', text: me.name + ' keluar dari grup' });
      chat.members = chat.members.filter(x => x !== me.id);
      chat.admins = chat.admins.filter(x => x !== me.id);
      if (!chat.admins.length && chat.members.length) chat.admins.push(chat.members[0]);
      saveDb();
      push([me.id, ...chat.members], 'chat', { chatId: chat.id, removed: true });
      return send(res, 200, { ok: true });
    }
  }

  if (method === 'POST' && p === '/api/messages/delete') {
    const b = await readBody(req);
    const chat = db.chats[b.chatId];
    if (!chat || !isMember(chat, me.id)) return fail(res, 404, 'Obrolan tidak ditemukan.');
    const msg = chatMsgs(chat.id).find(x => x.id === b.id);
    if (!msg || msg.from !== me.id) return fail(res, 403, 'Cuma bisa hapus pesan sendiri.');
    msg.deleted = true; msg.text = ''; msg.image = null;
    saveDb();
    push(chat.members, 'deleted', { chatId: chat.id, id: msg.id });
    return send(res, 200, { ok: true });
  }

  /* ---------- SALURAN ---------- */
  if (method === 'POST' && p === '/api/channels') {
    const b = await readBody(req);
    const name = clip(b.name, 40).trim();
    if (!name) return fail(res, 400, 'Nama saluran wajib diisi.');
    const id = 'c_' + rid(6);
    db.channels[id] = { id, name, description: clip(b.description, 200), photo: cleanUrl(b.photo), owner: me.id, followers: [me.id], createdAt: now() };
    db.posts[id] = [];
    saveDb();
    push(allUserIds(), 'sync', { what: 'channels' });
    return send(res, 200, { channel: channelSummary(db.channels[id], me.id) });
  }

  if ((m = /^\/api\/channels\/([\w]+)\/(follow|unfollow|update|posts|delete)$/.exec(p))) {
    const ch = db.channels[m[1]];
    if (!ch) return fail(res, 404, 'Saluran tidak ditemukan.');
    const action = m[2];
    if (method === 'GET' && action === 'posts') return send(res, 200, { posts: (db.posts[ch.id] || []).slice(-300) });
    if (method === 'POST' && action === 'follow') {
      if (!ch.followers.includes(me.id)) ch.followers.push(me.id);
      saveDb(); push(allUserIds(), 'sync', { what: 'channels' });
      return send(res, 200, { ok: true });
    }
    if (method === 'POST' && action === 'unfollow') {
      if (ch.owner === me.id) return fail(res, 400, 'Pemilik tidak bisa berhenti mengikuti.');
      ch.followers = ch.followers.filter(x => x !== me.id);
      saveDb(); push(allUserIds(), 'sync', { what: 'channels' });
      return send(res, 200, { ok: true });
    }
    if (method === 'POST' && action === 'update') {
      if (ch.owner !== me.id) return fail(res, 403, 'Hanya pemilik saluran.');
      const b = await readBody(req);
      if (typeof b.name === 'string' && b.name.trim()) ch.name = clip(b.name, 40).trim();
      if (typeof b.description === 'string') ch.description = clip(b.description, 200);
      if ('photo' in b) ch.photo = b.photo === null ? null : (cleanUrl(b.photo) || ch.photo);
      saveDb(); push(allUserIds(), 'sync', { what: 'channels' });
      return send(res, 200, { ok: true });
    }
    if (method === 'POST' && action === 'delete') {
      if (ch.owner !== me.id) return fail(res, 403, 'Hanya pemilik saluran.');
      delete db.channels[ch.id]; delete db.posts[ch.id];
      saveDb(); push(allUserIds(), 'sync', { what: 'channels', removed: ch.id });
      return send(res, 200, { ok: true });
    }
    if (method === 'POST' && action === 'posts') {
      if (ch.owner !== me.id) return fail(res, 403, 'Hanya pemilik saluran yang bisa posting.');
      const b = await readBody(req);
      const text = clip(b.text, 4000).trim(); const image = cleanUrl(b.image);
      if (!text && !image) return fail(res, 400, 'Postingan kosong.');
      const post = { id: 'p_' + rid(6), channelId: ch.id, text, image, ts: now(), reactions: {} };
      (db.posts[ch.id] = db.posts[ch.id] || []).push(post);
      saveDb();
      push(allUserIds(), 'post', { channelId: ch.id, post });
      return send(res, 200, { post });
    }
  }

  if (method === 'POST' && (m = /^\/api\/channels\/([\w]+)\/posts\/([\w]+)\/(react|delete)$/.exec(p))) {
    const ch = db.channels[m[1]];
    const post = ch && (db.posts[ch.id] || []).find(x => x.id === m[2]);
    if (!post) return fail(res, 404, 'Postingan tidak ditemukan.');
    if (m[3] === 'delete') {
      if (ch.owner !== me.id) return fail(res, 403, 'Hanya pemilik saluran.');
      db.posts[ch.id] = db.posts[ch.id].filter(x => x.id !== post.id);
      saveDb(); push(allUserIds(), 'sync', { what: 'posts', channelId: ch.id });
      return send(res, 200, { ok: true });
    }
    const b = await readBody(req);
    const emoji = clip(b.emoji, 8);
    if (!emoji) return fail(res, 400, 'Emoji kosong.');
    for (const k of Object.keys(post.reactions)) post.reactions[k] = post.reactions[k].filter(x => x !== me.id);
    if (b.on !== false) (post.reactions[emoji] = post.reactions[emoji] || []).push(me.id);
    for (const k of Object.keys(post.reactions)) if (!post.reactions[k].length) delete post.reactions[k];
    saveDb();
    push(allUserIds(), 'sync', { what: 'posts', channelId: ch.id });
    return send(res, 200, { post });
  }

  /* ---------- STATUS ---------- */
  if (method === 'POST' && p === '/api/status') {
    const b = await readBody(req);
    const type = b.type === 'image' ? 'image' : 'text';
    const text = clip(b.text, 700).trim();
    const image = type === 'image' ? cleanUrl(b.image) : null;
    if (type === 'text' && !text) return fail(res, 400, 'Tulis sesuatu dulu.');
    if (type === 'image' && !image) return fail(res, 400, 'Pilih foto dulu.');
    const tagUsers = (Array.isArray(b.tagUsers) ? b.tagUsers : []).filter(id => db.users[id] && id !== me.id).slice(0, 10);
    const tagGroups = (Array.isArray(b.tagGroups) ? b.tagGroups : []).filter(id => db.chats[id] && db.chats[id].type === 'group' && isMember(db.chats[id], me.id)).slice(0, 10);
    const s = { id: 's_' + rid(6), userId: me.id, type, text: type === 'text' ? text : '', caption: type === 'image' ? clip(b.caption, 300).trim() : '', bg: cleanColor(b.bg), image, ts: now(), expires: now() + STATUS_TTL, tags: { users: tagUsers, groups: tagGroups }, viewers: [] };
    db.statuses.push(s);
    /* Notifikasi tag: masuk sebagai pesan khusus di DM / grup yang ditandai */
    const ref = { id: s.id, ownerId: me.id, type: s.type, text: clip(s.text || s.caption, 80), image: s.image, bg: s.bg };
    for (const uid of tagUsers) addMessage(ensureDm(me.id, uid), me.id, { type: 'status_tag', text: me.name + ' menandai kamu di statusnya', statusRef: ref });
    for (const gid of tagGroups) addMessage(db.chats[gid], me.id, { type: 'status_tag', text: me.name + ' menandai grup ini di statusnya', statusRef: ref });
    saveDb();
    push(allUserIds(), 'sync', { what: 'statuses' });
    return send(res, 200, { status: statusView(s, me.id) });
  }

  if (method === 'POST' && (m = /^\/api\/status\/([\w]+)\/(view|delete)$/.exec(p))) {
    const s = db.statuses.find(x => x.id === m[1]);
    if (!s) return fail(res, 404, 'Status tidak ditemukan.');
    if (m[2] === 'delete') {
      if (s.userId !== me.id) return fail(res, 403, 'Bukan statusmu.');
      db.statuses = db.statuses.filter(x => x.id !== s.id);
      saveDb(); push(allUserIds(), 'sync', { what: 'statuses' });
      return send(res, 200, { ok: true });
    }
    if (s.userId !== me.id && !s.viewers.some(v => v.id === me.id)) {
      s.viewers.push({ id: me.id, ts: now() });
      saveDb(); push([s.userId], 'sync', { what: 'statuses' });
    }
    return send(res, 200, { ok: true });
  }

  return fail(res, 404, 'Endpoint tidak ada.');
}

/* ================= STATIC ================= */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.ico': 'image/x-icon', '.json': 'application/json' };
function serveFile(res, file, extra = {}) {
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, Object.assign({ 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff' }, extra));
    res.end(buf);
  });
}

const server = http.createServer(async (req, res) => {
  let urlObj;
  try { urlObj = new URL(req.url, 'http://localhost'); } catch (e) { res.writeHead(400); return res.end(); }
  const p = decodeURIComponent(urlObj.pathname);
  try {
    if (p.startsWith('/api/')) return await api(req, res, urlObj);
    if (p.startsWith('/uploads/')) {
      const f = path.join(UPLOAD_DIR, path.basename(p));
      return serveFile(res, f, { 'Cache-Control': 'public, max-age=31536000, immutable' });
    }
    const rel = p === '/' ? 'index.html' : p.replace(/^\/+/, '');
    const f = path.join(PUBLIC_DIR, rel);
    if (!f.startsWith(PUBLIC_DIR)) { res.writeHead(403); return res.end(); }
    return serveFile(res, f, { 'Cache-Control': 'no-cache' });
  } catch (e) {
    if (!res.headersSent) return fail(res, e.message === 'too_big' ? 413 : 400, e.message === 'too_big' ? 'Data terlalu besar.' : 'Permintaan tidak valid.');
  }
});

/* bersihkan status kedaluwarsa tiap 10 menit */
setInterval(() => {
  const t = now(); const before = db.statuses.length;
  db.statuses = db.statuses.filter(s => s.expires > t);
  if (db.statuses.length !== before) { saveDb(); push(allUserIds(), 'sync', { what: 'statuses' }); }
}, 10 * 60 * 1000);

server.listen(PORT, () => {
  console.log('Chat Kelas IX.6 jalan di http://localhost:' + PORT);
  console.log('Akun yang boleh dibuat: ' + ALLOWED.join(', '));
});
