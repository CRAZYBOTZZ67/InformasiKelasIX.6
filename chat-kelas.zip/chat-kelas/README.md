# Website Kelas IX.6 + Chat Kelas

Halaman `InformasiKelas.html` tetap ada, sekarang ditambah menu **CHAT KELAS**
(chat, grup, saluran, status). Tidak perlu `npm install`, cukup Node.js.

## Cara jalanin
```
node server.js
```
Buka http://localhost:3000 lalu klik menu **CHAT KELAS**.
(Port bisa diganti: `PORT=8080 node server.js`)

## Aturan akun
- Cuma 4 nama yang bisa daftar: Rizky, Chalista, Syakina, Nadira.
- 1 nama = 1 akun. Kalau sudah dipakai, nama itu tidak bisa didaftarkan lagi.

## Data
- `data/db.json`   : semua user, pesan, grup, saluran, status (JSON).
- `data/uploads/`  : foto profil, foto grup, foto chat, foto status.
Hapus folder `data/` untuk reset semuanya (akun bisa didaftarkan ulang).

## Deploy di VPS
Jalankan pakai pm2 / systemd: `pm2 start server.js --name chat-kelas`.
Pasang nginx + HTTPS di depannya, dan matikan buffering untuk `/api/events`
(sudah dikirim header `X-Accel-Buffering: no`).
